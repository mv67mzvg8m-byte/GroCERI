# Video2Shopping

Web app condivisibile che trasforma un video YouTube in una lista della spesa organizzata per reparto.

## Requisiti
- Account Vercel (hosting)
- Chiave API OpenAI da configurare come variabile segreta `OPENAI_API_KEY`

## Pubblicazione
1. Estrai lo ZIP e carica la cartella in un nuovo repository GitHub.
2. Importa il repository su https://vercel.com/new.
3. In Vercel → Project Settings → Environment Variables aggiungi:
   - `OPENAI_API_KEY` = la tua chiave API (non inserirla mai nel codice o nel browser)
   - `OPENAI_MODEL` = `gpt-4o-mini` (facoltativo)
4. Fai Deploy. Vercel fornirà un URL pubblico da condividere.
5. Apri l'URL su iPhone → Condividi → Aggiungi alla schermata Home.

## Come funziona
- La pagina accetta link YouTube e invia il video ID alla funzione serverless.
- La funzione tenta di recuperare i sottotitoli/trascrizione tramite `youtube-transcript`.
- La trascrizione viene inviata al modello OpenAI configurato e convertita in JSON strutturato.
- La lista è raggruppata per reparto; puoi spuntare, copiare, condividere e salvare le ricette nel browser del dispositivo.

## Limiti da conoscere
- La trascrizione deve essere accessibile. Video senza sottotitoli, con restrizioni o con protezioni anti-bot potrebbero non funzionare.
- Le quantità non dette nel video possono essere stimate dall'AI e vengono segnalate come tali.
- Le ricette salvate restano nel browser del dispositivo: non sono sincronizzate tra utenti o dispositivi.
- Per una vera collaborazione con liste condivise e archivio comune serve aggiungere un database e autenticazione.
- La chiave OpenAI è a carico del proprietario del progetto; ogni analisi può generare costi API.
- Questa app non è affiliata a YouTube o Esselunga.

## Sviluppo locale
Installa Node.js 20+, poi:
```bash
npm install
npx vercel dev
```
Configura `OPENAI_API_KEY` nell'ambiente locale o in `.env.local` (non committare questo file).
