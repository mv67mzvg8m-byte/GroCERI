import { YoutubeTranscript } from "youtube-transcript";

function extractId(body) {
  if (body.videoId) return body.videoId;
  const u = new URL(body.url);
  return u.hostname.includes("youtu.be") ? u.pathname.slice(1) : (u.searchParams.get("v") || u.pathname.split("/").pop());
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Metodo non supportato." });
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "L'app non è ancora configurata: manca la chiave AI del proprietario." });

  try {
    const { url, servings = 2, store = "Esselunga" } = req.body || {};
    const videoId = extractId(req.body || {});
    if (!videoId || !/^[\w-]{6,}$/.test(videoId)) return res.status(400).json({ error: "Link YouTube non valido." });

    let transcript = "";
    try {
      const rows = await YoutubeTranscript.fetchTranscript(videoId, { lang: "it" });
      transcript = rows.map(x => x.text).join(" ").slice(0, 45000);
    } catch {
      try {
        const rows = await YoutubeTranscript.fetchTranscript(videoId);
        transcript = rows.map(x => x.text).join(" ").slice(0, 45000);
      } catch {}
    }
    if (!transcript) {
      return res.status(422).json({ error: "Non è disponibile una trascrizione leggibile per questo video. Prova con un video che ha i sottotitoli attivi." });
    }

    let title = "Ricetta da YouTube";
    try {
      const o = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(url || `https://www.youtube.com/watch?v=${videoId}`)}&format=json`);
      if (o.ok) title = (await o.json()).title || title;
    } catch {}

    const prompt = `Sei un assistente culinario. Estrai la ricetta dalla trascrizione YouTube e prepara una lista della spesa per ${servings} persone, destinata a ${store}.
Titolo video: ${title}
TRASCRIZIONE:
${transcript}

Regole:
- Non inventare ingredienti non supportati. Se una quantità non è specificata, stima una quantità culinariamente plausibile e segnala "quantità stimata".
- Converti le quantità in unità pratiche da supermercato italiano (g, ml, pezzi, confezioni).
- Raggruppa gli ingredienti in reparti adatti a un supermercato italiano: Ortofrutta, Carne e pesce, Latticini e uova, Dispensa e conserve, Pane e prodotti da forno, Surgelati, Spezie e condimenti, Altro.
- Se un ingrediente è facoltativo, indicalo in note.
- Distingui ingredienti principali, guarnizioni e condimenti.
- Fornisci massimo 8 passaggi sintetici di preparazione, solo se ricavabili dalla trascrizione.
- Se il video non contiene una ricetta alimentare chiara, restituisci un errore.
Rispondi esclusivamente in JSON con questa struttura:
{"title":"...","servings":${servings},"store":"${store}","groups":[{"category":"Ortofrutta","items":[{"name":"...","quantity":"...","note":""}]}],"steps":["..."]}`;

    const ai = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "Rispondi solo con JSON valido. Non fingere di conoscere dettagli assenti dalla trascrizione." },
          { role: "user", content: prompt }
        ]
      })
    });
    if (!ai.ok) {
      const err = await ai.json().catch(() => ({}));
      throw new Error(err.error?.message || "Errore durante l'analisi AI.");
    }
    const payload = await ai.json();
    const content = payload.choices?.[0]?.message?.content;
    if (!content) throw new Error("L'AI non ha restituito una ricetta.");
    const recipe = JSON.parse(content);
    if (!Array.isArray(recipe.groups)) throw new Error("Formato ricetta non valido.");
    return res.status(200).json({ ...recipe, title: recipe.title || title, servings, store });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message || "Errore inatteso. Riprova più tardi." });
  }
}